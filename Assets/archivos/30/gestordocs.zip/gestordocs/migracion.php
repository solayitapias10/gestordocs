<?php
/**
 * Script de migración para reorganizar archivos existentes.
 * Ejecutar UNA SOLA VEZ después de implementar los cambios.
 */

// MODO SIMULACRO: true para ver qué haría, false para ejecutarlo de verdad.
$dryRun = false; 

// CAMBIO 1: Incluir los archivos correctos de tu proyecto
require_once 'Config/Config.php';
require_once 'Config/App/Conexion.php';
require_once 'Config/App/Query.php';

echo "=== MIGRACIÓN DE ARCHIVOS A ESTRUCTURA POR USUARIO ===\n";
if ($dryRun) {
    echo "!!! MODO SIMULACRO ACTIVADO: No se moverán archivos. !!!\n\n";
}

try {
    // CAMBIO 2: Usar tu clase Query para la conexión y las consultas
    $db = new Query();
    
    // Obtener todos los usuarios activos
    $usuarios = $db->selectAll("SELECT id FROM usuarios WHERE estado = 1");
    
    foreach ($usuarios as $usuario) {
        $id_usuario = $usuario['id'];
        $carpeta_usuario = "Assets/archivos/{$id_usuario}";
        
        // Crear carpeta del usuario si no existe
        if (!file_exists($carpeta_usuario)) {
            // Usar permisos seguros 0755
            if (!$dryRun && !mkdir($carpeta_usuario, 0755, true)) {
                echo "Error: No se pudo crear carpeta para usuario {$id_usuario}\n";
                continue;
            }
            echo "✓ Carpeta creada para usuario {$id_usuario}\n";
        }
        
        // Obtener archivos del usuario
        $archivos = $db->selectAll(
            "SELECT id, nombre, id_carpeta FROM archivos WHERE id_usuario = ? AND estado = 1",
            [$id_usuario]
        );
        
        foreach ($archivos as $archivo) {
            // La lógica para mover archivos ya era correcta y no necesita cambios
            $ruta_nueva_base = "Assets/archivos/{$id_usuario}/";
            if ($archivo['id_carpeta']) {
                $ruta_antigua = "Assets/archivos/{$archivo['id_carpeta']}/{$archivo['nombre']}";
                $ruta_nueva = $ruta_nueva_base . "{$archivo['id_carpeta']}/{$archivo['nombre']}";
                
                $carpeta_especifica = $ruta_nueva_base . $archivo['id_carpeta'];
                if (!file_exists($carpeta_especifica)) {
                    if (!$dryRun) mkdir($carpeta_especifica, 0755, true);
                }
            } else {
                $ruta_antigua = "Assets/archivos/{$archivo['nombre']}";
                $ruta_nueva = $ruta_nueva_base . $archivo['nombre'];
            }
            
            if (file_exists($ruta_antigua)) {
                if ($dryRun) {
                    echo "[SIMULACRO] Movería: {$ruta_antigua} -> {$ruta_nueva}\n";
                } else {
                    if (rename($ruta_antigua, $ruta_nueva)) {
                        echo "✓ Movido: {$archivo['nombre']} para usuario {$id_usuario}\n";
                    } else {
                        $error = error_get_last();
                        echo "✗ Error moviendo: {$archivo['nombre']}. Motivo: " . ($error['message'] ?? 'Desconocido') . "\n";
                    }
                }
            }
        }
    }
    
    echo "\n=== MIGRACIÓN COMPLETADA ===\n";
    
} catch (Exception $e) {
    echo "Error durante la migración: " . $e->getMessage() . "\n";
}
?>