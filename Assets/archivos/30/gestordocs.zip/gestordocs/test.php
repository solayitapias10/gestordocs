<?php
/********************************************
 * test_email.php
 * Script para probar envío de emails
 ********************************************/

require_once 'vendor/autoload.php';
require_once 'Config/Config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

echo "<h2>Test de Email</h2>";

try {
    $mail = new PHPMailer(true);
    
    // Configuración básica
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;
    $mail->SMTPAuth = SMTP_AUTH;
    $mail->Username = SMTP_USERNAME;
    $mail->Password = SMTP_PASSWORD;
    $mail->SMTPSecure = SMTP_SECURE;
    $mail->Port = SMTP_PORT;
    
    // Habilitar debug
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    
    // Configurar email de prueba
    $mail->setFrom(MAIL_FROM_EMAIL, 'Test Sistema');
    $mail->addAddress('tu-email@ejemplo.com', 'Test Usuario'); // Cambiar por tu email
    
    $mail->isHTML(true);
    $mail->Subject = 'Email de Prueba - ' . date('Y-m-d H:i:s');
    $mail->Body = '<h1>¡Test Exitoso!</h1><p>El servicio de email funciona correctamente.</p>';
    
    echo "<h3>Intentando enviar email...</h3>";
    echo "<div style='background: #f0f0f0; padding: 10px; font-family: monospace; overflow-x: auto;'>";
    
    ob_start();
    $resultado = $mail->send();
    $debug_output = ob_get_clean();
    
    echo htmlspecialchars($debug_output);
    echo "</div>";
    
    if ($resultado) {
        echo "<h3 style='color: green;'>✅ EMAIL ENVIADO CORRECTAMENTE</h3>";
    } else {
        echo "<h3 style='color: red;'>❌ ERROR AL ENVIAR EMAIL</h3>";
    }
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>❌ EXCEPCIÓN: " . $e->getMessage() . "</h3>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<h3>Configuración Actual:</h3>";
echo "<strong>SMTP_HOST:</strong> " . (defined('SMTP_HOST') ? SMTP_HOST : 'NO DEFINIDO') . "<br>";
echo "<strong>SMTP_PORT:</strong> " . (defined('SMTP_PORT') ? SMTP_PORT : 'NO DEFINIDO') . "<br>";
echo "<strong>SMTP_USERNAME:</strong> " . (defined('SMTP_USERNAME') ? SMTP_USERNAME : 'NO DEFINIDO') . "<br>";
echo "<strong>MAIL_FROM_EMAIL:</strong> " . (defined('MAIL_FROM_EMAIL') ? MAIL_FROM_EMAIL : 'NO DEFINIDO') . "<br>";
?>