-- =====================================================
--           EJEMPLOS DE PRUEBA DE FUNCIONES
-- =====================================================

--  Función para obtener archivos compartidos conmigo
SELECT * FROM obtener_archivos_compartidos_conmigo('usuario@gmail.com');

-- Función para obtener detalles de un archivo compartido
SELECT * FROM obtener_detalle_archivo_compartido(3,'usuario@gmail.com');

--Función  para verificar permisos de archivo compartido
SELECT * FROM verificar_archivo_compartido_usuario(3, 'usuario@gmail.com');

-- Función mejorada para cambiar estado de archivo compartido
SELECT cambiar_estado_archivo_compartido(1, 1);

-- Función para marcar archivo como visto
SELECT marcar_archivo_como_visto(1);

-- Función para obtener estadísticas de compartidos de usuario
SELECT * FROM obtener_estadisticas_compartidos_usuario('usuario@gmail.com');

-- Función para obtener estadísticas globales de compartidos
SELECT * FROM obtener_estadisticas_compartidos_globales();

-- Función para limpiar tokens expirados
SELECT limpiar_tokens_expirados();

-- Función para invalidar tokens de usuario
SELECT invalidar_tokens_usuario(1);

-- Función para obtener información de errores de validación
SELECT * FROM validar_solicitud_compartido(6, 'prueba@gmail.com', 2);

