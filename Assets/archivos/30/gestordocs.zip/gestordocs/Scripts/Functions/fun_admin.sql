-- =====================================================
-- FUNCIONES CONTROLADOR ADMIN
-- =====================================================

-- 1. Obtiene las carpetas principales de un usuario
CREATE OR REPLACE FUNCTION obtener_carpetas_principales(
    p_id_usuario carpetas.id_usuario%TYPE
)
RETURNS TABLE (
    id carpetas.id%TYPE,
    nombre carpetas.nombre%TYPE,
    fecha_create carpetas.fecha_create%TYPE,
    estado carpetas.estado%TYPE,
    elimina carpetas.elimina%TYPE,
    id_usuario carpetas.id_usuario%TYPE,
    id_carpeta_padre carpetas.id_carpeta_padre%TYPE
) AS $$
BEGIN
    -- Validar parámetros de entrada
    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RAISE EXCEPTION 'ID de usuario inválido';
    END IF;

    -- Retornar las carpetas principales del usuario
    RETURN QUERY 
    SELECT 
        c.id,
        c.nombre,
        c.fecha_create,
        c.estado,
        c.elimina,
        c.id_usuario,
        c.id_carpeta_padre
    FROM carpetas c
    WHERE c.id_usuario = p_id_usuario 
      AND c.id_carpeta_padre IS NULL 
      AND c.estado = 1
    ORDER BY c.fecha_create DESC;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al obtener carpetas principales: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;


-- 2. Obtiene las subcarpetas de una carpeta específica para un usuario
CREATE OR REPLACE FUNCTION obtener_subcarpetas(
    p_id_carpeta carpetas.id_carpeta_padre%TYPE,
    p_id_usuario carpetas.id_usuario%TYPE
)
RETURNS TABLE (
    id carpetas.id%TYPE,
    nombre carpetas.nombre%TYPE,
    fecha_create carpetas.fecha_create%TYPE,
    estado carpetas.estado%TYPE,
    elimina carpetas.elimina%TYPE,
    id_usuario carpetas.id_usuario%TYPE,
    id_carpeta_padre carpetas.id_carpeta_padre%TYPE
) AS $$
BEGIN
    -- Validar parámetros de entrada
    IF p_id_carpeta IS NULL OR p_id_carpeta <= 0 THEN
        RAISE EXCEPTION 'ID de carpeta padre inválido';
    END IF;

    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RAISE EXCEPTION 'ID de usuario inválido';
    END IF;

    -- Verificar que el usuario existe y está activo
    IF NOT EXISTS(SELECT 1 FROM usuarios u WHERE u.id = p_id_usuario AND u.estado = 1) THEN
        RAISE EXCEPTION 'El usuario no existe o está inactivo';
    END IF;

    -- Verificar que la carpeta padre existe, está activa y pertenece al usuario
    IF NOT EXISTS(
        SELECT 1 FROM carpetas cp 
        WHERE cp.id = p_id_carpeta 
          AND cp.id_usuario = p_id_usuario 
          AND cp.estado = 1
    ) THEN
        RAISE EXCEPTION 'La carpeta padre no existe, no está activa o no pertenece al usuario';
    END IF;

    -- Retornar las subcarpetas
    RETURN QUERY 
    SELECT 
        c.id,
        c.nombre,
        c.fecha_create,
        c.estado,
        c.elimina,
        c.id_usuario,
        c.id_carpeta_padre
    FROM carpetas c
    WHERE c.id_carpeta_padre = p_id_carpeta 
      AND c.id_usuario = p_id_usuario 
      AND c.estado = 1 
    ORDER BY c.id DESC;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al obtener subcarpetas: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;


-- 3. Verifica si ya existe una carpeta con el mismo nombre para evitar duplicados
CREATE OR REPLACE FUNCTION verificar_carpeta_existente(
    p_campo VARCHAR(50),                    
    p_valor VARCHAR(255),                   
    p_id_usuario carpetas.id_usuario%TYPE,  
    p_id_excluir carpetas.id%TYPE DEFAULT 0, 
    p_id_carpeta_padre carpetas.id_carpeta_padre%TYPE DEFAULT NULL 
)
RETURNS TABLE (
    id carpetas.id%TYPE,
    existe BOOLEAN,
    mensaje TEXT
) AS $$
DECLARE
    v_id_encontrado carpetas.id%TYPE;
    v_mensaje TEXT;
    v_existe BOOLEAN;
    v_campo_limpio VARCHAR(50);
    v_valor_limpio VARCHAR(255);
BEGIN
    -- Validar parámetros de entrada
    IF p_campo IS NULL OR TRIM(p_campo) = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, FALSE, 'El campo no puede estar vacío'::TEXT;
        RETURN;
    END IF;

    IF p_valor IS NULL OR TRIM(p_valor) = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, FALSE, 'El valor no puede estar vacío'::TEXT;
        RETURN;
    END IF;

    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RETURN QUERY SELECT NULL::INTEGER, FALSE, 'ID de usuario inválido'::TEXT;
        RETURN;
    END IF;

    -- Limpiar valores
    v_campo_limpio := TRIM(p_campo);
    v_valor_limpio := TRIM(p_valor);

    -- Validar que el campo sea permitido (por seguridad)
    IF v_campo_limpio NOT IN ('nombre') THEN
        RETURN QUERY SELECT NULL::INTEGER, FALSE, 'Campo no válido. Solo se permite: nombre'::TEXT;
        RETURN;
    END IF;

    -- Verificar que el usuario existe y está activo
    IF NOT EXISTS(SELECT 1 FROM usuarios u WHERE u.id = p_id_usuario AND u.estado = 1) THEN
        RETURN QUERY SELECT NULL::INTEGER, FALSE, 'El usuario no existe o está inactivo'::TEXT;
        RETURN;
    END IF;

    -- Si se especifica carpeta padre, verificar que existe y pertenece al usuario
    IF p_id_carpeta_padre IS NOT NULL THEN
        IF NOT EXISTS(
            SELECT 1 FROM carpetas cp 
            WHERE cp.id = p_id_carpeta_padre 
              AND cp.id_usuario = p_id_usuario 
              AND cp.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, FALSE, 'La carpeta padre no existe o no pertenece al usuario'::TEXT;
            RETURN;
        END IF;
    END IF;

    -- Verificar existencia según los parámetros
    IF p_id_excluir > 0 THEN
        -- Para actualizaciones: excluir el ID específico
        IF p_id_carpeta_padre IS NULL THEN
            -- Carpeta en la raíz
            SELECT c.id INTO v_id_encontrado
            FROM carpetas c 
            WHERE c.nombre = v_valor_limpio 
              AND c.id_usuario = p_id_usuario 
              AND c.id_carpeta_padre IS NULL 
              AND c.id != p_id_excluir 
              AND c.estado = 1
            LIMIT 1;
        ELSE
            -- Carpeta dentro de otra carpeta
            SELECT c.id INTO v_id_encontrado
            FROM carpetas c 
            WHERE c.nombre = v_valor_limpio 
              AND c.id_usuario = p_id_usuario 
              AND c.id_carpeta_padre = p_id_carpeta_padre 
              AND c.id != p_id_excluir 
              AND c.estado = 1
            LIMIT 1;
        END IF;
    ELSE
        -- Para nuevos registros: sin exclusión
        IF p_id_carpeta_padre IS NULL THEN
            -- Carpeta en la raíz
            SELECT c.id INTO v_id_encontrado
            FROM carpetas c 
            WHERE c.nombre = v_valor_limpio 
              AND c.id_usuario = p_id_usuario 
              AND c.id_carpeta_padre IS NULL 
              AND c.estado = 1
            LIMIT 1;
        ELSE
            -- Carpeta dentro de otra carpeta
            SELECT c.id INTO v_id_encontrado
            FROM carpetas c 
            WHERE c.nombre = v_valor_limpio 
              AND c.id_usuario = p_id_usuario 
              AND c.id_carpeta_padre = p_id_carpeta_padre 
              AND c.estado = 1
            LIMIT 1;
        END IF;
    END IF;

    -- Determinar el resultado y mensaje
    IF v_id_encontrado IS NOT NULL THEN
        v_existe := TRUE;
        IF p_id_excluir > 0 THEN
            v_mensaje := 'Ya existe otra carpeta con este nombre en la misma ubicación. No se puede actualizar.';
        ELSE
            v_mensaje := 'Ya existe una carpeta con este nombre en la misma ubicación. No se puede crear.';
        END IF;
    ELSE
        v_existe := FALSE;
        IF p_id_excluir > 0 THEN
            v_mensaje := 'El nombre está disponible para actualización.';
        ELSE
            v_mensaje := 'El nombre está disponible para crear la carpeta.';
        END IF;
        -- Para mantener compatibilidad con el código original
        v_id_encontrado := NULL;
    END IF;

    -- Retornar resultado
    RETURN QUERY SELECT v_id_encontrado, v_existe, v_mensaje;

EXCEPTION
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::INTEGER, TRUE, ('Error al verificar carpeta: ' || SQLERRM)::TEXT;
END;
$$ LANGUAGE plpgsql;

-- 4. Función para crear una nueva carpeta con validaciones completas
CREATE OR REPLACE FUNCTION crear_carpeta(
    p_nombre carpetas.nombre%TYPE,
    p_id_usuario carpetas.id_usuario%TYPE,
    p_id_carpeta_padre carpetas.id_carpeta_padre%TYPE DEFAULT NULL
)
RETURNS TABLE (
    id_carpeta_nueva carpetas.id%TYPE,
    mensaje TEXT,
    exito BOOLEAN
) AS $$
DECLARE
    v_id_nueva_carpeta carpetas.id%TYPE;
    v_nombre_limpio VARCHAR(255);
    v_mensaje TEXT;
    v_exito BOOLEAN;
BEGIN
    -- Validar parámetros de entrada
    IF p_nombre IS NULL OR TRIM(p_nombre) = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El nombre de la carpeta es requerido'::TEXT, FALSE;
        RETURN;
    END IF;

    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ID de usuario inválido'::TEXT, FALSE;
        RETURN;
    END IF;

    -- Limpiar el nombre
    v_nombre_limpio := TRIM(p_nombre);
    
    -- Validar longitud del nombre
    IF LENGTH(v_nombre_limpio) > 255 THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El nombre de la carpeta es demasiado largo (máximo 255 caracteres)'::TEXT, FALSE;
        RETURN;
    END IF;

    -- Verificar que el usuario existe y está activo
    IF NOT EXISTS(SELECT 1 FROM usuarios u WHERE u.id = p_id_usuario AND u.estado = 1) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El usuario no existe o está inactivo'::TEXT, FALSE;
        RETURN;
    END IF;

    -- Si se especifica carpeta padre, verificar que existe y pertenece al usuario
    IF p_id_carpeta_padre IS NOT NULL THEN
        IF NOT EXISTS(
            SELECT 1 FROM carpetas cp 
            WHERE cp.id = p_id_carpeta_padre 
              AND cp.id_usuario = p_id_usuario 
              AND cp.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, 'La carpeta padre no existe, no está activa o no pertenece al usuario'::TEXT, FALSE;
            RETURN;
        END IF;
    END IF;

    -- Verificar que no existe una carpeta con el mismo nombre en la misma ubicación
    IF p_id_carpeta_padre IS NULL THEN
        -- Carpeta en la raíz
        IF EXISTS(
            SELECT 1 FROM carpetas c 
            WHERE c.nombre = v_nombre_limpio 
              AND c.id_usuario = p_id_usuario 
              AND c.id_carpeta_padre IS NULL 
              AND c.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, 'Ya existe una carpeta con este nombre en la raíz'::TEXT, FALSE;
            RETURN;
        END IF;
    ELSE
        -- Carpeta dentro de otra carpeta
        IF EXISTS(
            SELECT 1 FROM carpetas c 
            WHERE c.nombre = v_nombre_limpio 
              AND c.id_usuario = p_id_usuario 
              AND c.id_carpeta_padre = p_id_carpeta_padre 
              AND c.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, 'Ya existe una carpeta con este nombre en esta ubicación'::TEXT, FALSE;
            RETURN;
        END IF;
    END IF;

    -- Crear la carpeta
    INSERT INTO carpetas (nombre, id_usuario, id_carpeta_padre, fecha_create, estado)
    VALUES (v_nombre_limpio, p_id_usuario, p_id_carpeta_padre, CURRENT_TIMESTAMP, 1)
    RETURNING id INTO v_id_nueva_carpeta;

    -- Verificar que se creó correctamente
    IF v_id_nueva_carpeta IS NOT NULL THEN
        v_exito := TRUE;
        v_mensaje := 'Carpeta creada exitosamente';
    ELSE
        v_exito := FALSE;
        v_mensaje := 'Error al crear la carpeta';
    END IF;

    -- Retornar resultado
    RETURN QUERY SELECT v_id_nueva_carpeta, v_mensaje, v_exito;

EXCEPTION
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::INTEGER, ('Error al crear carpeta: ' || SQLERRM)::TEXT, FALSE;
END;
$$ LANGUAGE plpgsql;

-- 5 Función para marcar una carpeta como eliminada con validaciones
CREATE OR REPLACE FUNCTION eliminar_carpeta(
    p_id_carpeta carpetas.id%TYPE,
    p_id_usuario carpetas.id_usuario%TYPE DEFAULT NULL
)
RETURNS INTEGER AS $$
DECLARE
    v_carpeta_existe carpetas%ROWTYPE;
    v_filas_afectadas INTEGER;
BEGIN
    -- Validar parámetros de entrada
    IF p_id_carpeta IS NULL OR p_id_carpeta <= 0 THEN
        RAISE EXCEPTION 'ID de carpeta inválido';
    END IF;

    -- Verificar que la carpeta existe
    SELECT * INTO v_carpeta_existe 
    FROM carpetas 
    WHERE id = p_id_carpeta;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'La carpeta no existe';
    END IF;

    -- Verificar que la carpeta no está ya eliminada
    IF v_carpeta_existe.estado = 0 THEN
        RAISE EXCEPTION 'La carpeta ya está eliminada';
    END IF;

    -- Si se proporciona id_usuario, verificar que sea el propietario
    IF p_id_usuario IS NOT NULL THEN
        IF v_carpeta_existe.id_usuario != p_id_usuario THEN
            RAISE EXCEPTION 'No tienes permiso para eliminar esta carpeta';
        END IF;
    END IF;

    -- Marcar la carpeta como eliminada con fecha de eliminación
    UPDATE carpetas 
    SET estado = 0, 
        elimina = CURRENT_TIMESTAMP + INTERVAL '30 days'
    WHERE id = p_id_carpeta;

    GET DIAGNOSTICS v_filas_afectadas = ROW_COUNT;

    -- Retornar las filas afectadas
    RETURN v_filas_afectadas;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al eliminar carpeta: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

-- 6. Procedimiento para subir un archivo con validaciones
CREATE OR REPLACE FUNCTION subir_archivo(
    p_nombre archivos.nombre%TYPE,
    p_tipo archivos.tipo%TYPE,
    p_tamano archivos.tamano%TYPE,
    p_id_carpeta archivos.id_carpeta%TYPE,
    p_id_usuario archivos.id_usuario%TYPE
)
RETURNS TABLE (
    id_archivo_nuevo archivos.id%TYPE,
    mensaje TEXT,
    exito BOOLEAN
) AS $$
DECLARE
    v_id_nuevo_archivo archivos.id%TYPE;
    v_nombre_limpio VARCHAR(255);
    v_mensaje TEXT;
    v_exito BOOLEAN;
BEGIN
    -- Validar parámetros de entrada
    IF p_nombre IS NULL OR TRIM(p_nombre) = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El nombre del archivo es requerido'::TEXT, FALSE;
        RETURN;
    END IF;

    IF p_tipo IS NULL OR TRIM(p_tipo) = '' THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El tipo del archivo es requerido'::TEXT, FALSE;
        RETURN;
    END IF;

    IF p_tamano IS NULL OR p_tamano < 0 THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El tamaño del archivo es inválido'::TEXT, FALSE;
        RETURN;
    END IF;

    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RETURN QUERY SELECT NULL::INTEGER, 'ID de usuario inválido'::TEXT, FALSE;
        RETURN;
    END IF;

    -- Limpiar el nombre
    v_nombre_limpio := TRIM(p_nombre);
    
    -- Validar longitud del nombre
    IF LENGTH(v_nombre_limpio) > 255 THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El nombre del archivo es demasiado largo (máximo 255 caracteres)'::TEXT, FALSE;
        RETURN;
    END IF;

    -- Verificar que el usuario existe y está activo
    IF NOT EXISTS(SELECT 1 FROM usuarios u WHERE u.id = p_id_usuario AND u.estado = 1) THEN
        RETURN QUERY SELECT NULL::INTEGER, 'El usuario no existe o está inactivo'::TEXT, FALSE;
        RETURN;
    END IF;

    -- Si se especifica carpeta, verificar que existe y pertenece al usuario
    IF p_id_carpeta IS NOT NULL THEN
        IF NOT EXISTS(
            SELECT 1 FROM carpetas c 
            WHERE c.id = p_id_carpeta 
              AND c.id_usuario = p_id_usuario 
              AND c.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, 'La carpeta no existe, no está activa o no pertenece al usuario'::TEXT, FALSE;
            RETURN;
        END IF;
    END IF;

    -- Verificar que no existe un archivo con el mismo nombre en la misma ubicación
    IF p_id_carpeta IS NULL THEN
        -- Archivo en la raíz
        IF EXISTS(
            SELECT 1 FROM archivos a 
            WHERE a.nombre = v_nombre_limpio 
              AND a.id_usuario = p_id_usuario 
              AND a.id_carpeta IS NULL 
              AND a.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, 'Ya existe un archivo con este nombre en la raíz'::TEXT, FALSE;
            RETURN;
        END IF;
    ELSE
        -- Archivo dentro de una carpeta
        IF EXISTS(
            SELECT 1 FROM archivos a 
            WHERE a.nombre = v_nombre_limpio 
              AND a.id_usuario = p_id_usuario 
              AND a.id_carpeta = p_id_carpeta 
              AND a.estado = 1
        ) THEN
            RETURN QUERY SELECT NULL::INTEGER, 'Ya existe un archivo con este nombre en esta carpeta'::TEXT, FALSE;
            RETURN;
        END IF;
    END IF;

    -- Insertar el archivo
    INSERT INTO archivos (nombre, tipo, tamano, id_carpeta, id_usuario, fecha_create, estado)
    VALUES (v_nombre_limpio, TRIM(p_tipo), p_tamano, p_id_carpeta, p_id_usuario, CURRENT_TIMESTAMP, 1)
    RETURNING id INTO v_id_nuevo_archivo;

    -- Verificar que se creó correctamente
    IF v_id_nuevo_archivo IS NOT NULL THEN
        v_exito := TRUE;
        v_mensaje := 'Archivo subido exitosamente';
    ELSE
        v_exito := FALSE;
        v_mensaje := 'Error al subir el archivo';
    END IF;

    -- Retornar resultado
    RETURN QUERY SELECT v_id_nuevo_archivo, v_mensaje, v_exito;

EXCEPTION
    WHEN OTHERS THEN
        RETURN QUERY SELECT NULL::INTEGER, ('Error al subir archivo: ' || SQLERRM)::TEXT, FALSE;
END;
$$ LANGUAGE plpgsql;

-- 7. Procedimiento para obtener archivos recientes de un usuario
CREATE OR REPLACE FUNCTION obtener_archivos_recientes(
    p_id_usuario archivos.id_usuario%TYPE,
    p_limite INTEGER DEFAULT 4
)
RETURNS TABLE (
    id archivos.id%TYPE,
    nombre archivos.nombre%TYPE,
    tipo archivos.tipo%TYPE,
    fecha_create archivos.fecha_create%TYPE,
    estado archivos.estado%TYPE,
    elimina archivos.elimina%TYPE,
    id_carpeta archivos.id_carpeta%TYPE,
    id_usuario archivos.id_usuario%TYPE,
    tamano archivos.tamano%TYPE
) AS $$
BEGIN
    -- Validar parámetros de entrada
    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RAISE EXCEPTION 'ID de usuario inválido';
    END IF;

    IF p_limite IS NULL OR p_limite <= 0 THEN
        p_limite := 4; -- Valor por defecto
    END IF;

    -- Verificar que el usuario existe y está activo
    IF NOT EXISTS(SELECT 1 FROM usuarios u WHERE u.id = p_id_usuario AND u.estado = 1) THEN
        RAISE EXCEPTION 'El usuario no existe o está inactivo';
    END IF;

    -- Retornar los archivos recientes del usuario (archivos en la raíz)
    RETURN QUERY 
    SELECT 
        a.id,
        a.nombre,
        a.tipo,
        a.fecha_create,
        a.estado,
        a.elimina,
        a.id_carpeta,
        a.id_usuario,
        a.tamano
    FROM archivos a
    WHERE a.id_usuario = p_id_usuario 
      AND a.id_carpeta IS NULL 
      AND a.estado = 1
    ORDER BY a.id DESC 
    LIMIT p_limite;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al obtener archivos recientes: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;

-- 8. Procedimiento para obtener todos los archivos de una carpeta específica
CREATE OR REPLACE FUNCTION obtener_archivos_carpeta(
    p_id_carpeta archivos.id_carpeta%TYPE,
    p_id_usuario archivos.id_usuario%TYPE
)
RETURNS TABLE (
    id archivos.id%TYPE,
    nombre archivos.nombre%TYPE,
    tipo archivos.tipo%TYPE,
    fecha_create archivos.fecha_create%TYPE,
    estado archivos.estado%TYPE,
    elimina archivos.elimina%TYPE,
    id_carpeta archivos.id_carpeta%TYPE,
    id_usuario archivos.id_usuario%TYPE,
    tamano archivos.tamano%TYPE
) AS $$
BEGIN
    -- Validar parámetros de entrada
    IF p_id_carpeta IS NULL OR p_id_carpeta <= 0 THEN
        RAISE EXCEPTION 'ID de carpeta inválido';
    END IF;

    IF p_id_usuario IS NULL OR p_id_usuario <= 0 THEN
        RAISE EXCEPTION 'ID de usuario inválido';
    END IF;

    -- Verificar que el usuario existe y está activo
    IF NOT EXISTS(SELECT 1 FROM usuarios u WHERE u.id = p_id_usuario AND u.estado = 1) THEN
        RAISE EXCEPTION 'El usuario no existe o está inactivo';
    END IF;

    -- Verificar que la carpeta existe, está activa y pertenece al usuario
    IF NOT EXISTS(
        SELECT 1 FROM carpetas c 
        WHERE c.id = p_id_carpeta 
          AND c.id_usuario = p_id_usuario 
          AND c.estado = 1
    ) THEN
        RAISE EXCEPTION 'La carpeta no existe, no está activa o no pertenece al usuario';
    END IF;

    -- Retornar los archivos de la carpeta específica
    RETURN QUERY 
    SELECT 
        a.id,
        a.nombre,
        a.tipo,
        a.fecha_create,
        a.estado,
        a.elimina,
        a.id_carpeta,
        a.id_usuario,
        a.tamano
    FROM archivos a
    WHERE a.id_carpeta = p_id_carpeta 
      AND a.id_usuario = p_id_usuario 
      AND a.estado = 1 
    ORDER BY a.id DESC;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al obtener archivos de la carpeta: %', SQLERRM;
END;
$$ LANGUAGE plpgsql;