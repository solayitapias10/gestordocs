
 select * from usuarios

SELECT * FROM cambiar_clave_usuario (7,'$2y$12$ongBYwNSUDuMvCgICkN97O0rp9wdVsJJX62zYJ3y0VED3rQ.NzkWK')


