<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Error - GestorDocs">
    <title><?php echo $data['title']; ?></title>
    
    <!-- Estilos -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined" rel="stylesheet">
    <link href="<?php echo BASE_URL . 'Assets/plugins/bootstrap/css/bootstrap.min.css'; ?>" rel="stylesheet">
    <link href="<?php echo BASE_URL . 'Assets/css/main.min.css'; ?>" rel="stylesheet">
    <link href="<?php echo BASE_URL . 'Assets/css/custom.css'; ?>" rel="stylesheet">
    <link rel="icon" href="<?php echo BASE_URL . 'Assets/images/favicon.ico'; ?>">
</head>

<body>
    <div class="app app-auth-sign-in align-content-stretch d-flex flex-wrap justify-content-end">
        <div class="app-auth-background"></div>
        <div class="app-auth-container">
            <!-- Logo y título -->
            <div class="logo d-flex align-items-center mb-0">
                <img src="<?php echo BASE_URL . 'Assets/images/logo.png'; ?>" alt="GestorDocs Logo" class="me-2" style="width: 32px; height: 32px;">
                <span class="fs-3 fw-bold text-danger">Error</span>
            </div>

            <!-- Mensaje de error -->
            <div class="text-center mt-4">
                <i class="material-icons text-danger" style="font-size: 4rem;">error_outline</i>
                <h3 class="mt-3 text-danger">¡Ups! Algo salió mal</h3>
                <p class="text-muted mt-2">
                    <?php echo htmlspecialchars($data['error']); ?>
                </p>
            </div>

            <!-- Acciones disponibles -->
            <div class="text-center mt-4">
                <a href="<?php echo BASE_URL . 'recuperar/index'; ?>" class="btn btn-primary me-2">
                    <i class="material-icons me-2">refresh</i>
                    Solicitar Nuevo Enlace
                </a>
                <a href="<?php echo BASE_URL . 'principal/index'; ?>" class="btn btn-outline-secondary">
                    <i class="material-icons me-2">home</i>
                    Ir al Login
                </a>
            </div>

            <!-- Información adicional -->
            <div class="alert alert-info mt-4" role="alert">
                <i class="material-icons me-2">info</i>
                <strong>¿Necesitas ayuda?</strong>
                <p class="mb-0 mt-2">
                    Si continúas teniendo problemas, puedes solicitar un nuevo enlace de recuperación 
                    o contactar al administrador del sistema.
                </p>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo BASE_URL . 'Assets/plugins/jquery/jquery-3.5.1.min.js'; ?>"></script>
    <script src="<?php echo BASE_URL . 'Assets/plugins/bootstrap/js/bootstrap.min.js'; ?>"></script>
</body>
</html>