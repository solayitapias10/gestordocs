INSERT INTO usuarios (id, nombre, apellido, correo, telefono, direccion, clave, rol)
VALUES (
    1,
    'Sol',
    'Tapias',
    'solayitapias@gmail.com',
    '3023441358',
    'Calle 13 PET 15 3 08',
    '$2y$10$QYZlYr5ZX2l31PVEBYaGwu4vqGjom1VUPvT9O90CiO1R25XLaqN.y',
    1
);
