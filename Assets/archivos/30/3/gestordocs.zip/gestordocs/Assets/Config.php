<?php
const BASE_URL = "http://10.5.213.111/gestordocs/";
const HOST = "10.5.213.111"; 
const PORT = "5432"; 
const USER = "sgonzalez"; 
const PASS = "sgonzalez123"; 
const DB = "gestion_archivo";
const CHARSET = "charset=utf8";
const SECRET_KEY = "TuClaveSecreta2025!GestionDocs"; 
const GOOGLE_API_KEY = "AIzaSyCRM5PVcZuRliLGccykmpqbKkkTY9zHlsE";
const GOOGLE_CX_ID = "17f58a4640d1d4e6b";
?>