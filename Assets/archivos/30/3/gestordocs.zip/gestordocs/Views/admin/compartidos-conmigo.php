<?php
/********************************************
Archivo php admin/compartidos-conmigo.php                         
Creado por el equipo Gaes 1:            
Anyi Solayi Tapias                  
Sharit Delgado Pinzón               
Durly Yuranni Sánchez Carillo       
Año: 2025                              
SENA - CSET - ADSO                    
 ********************************************/

// Incluye la cabecera de la página
include_once 'Views/template/header.php'; 
?>
<div class="app-content">
    <?php 
    // Incluye el menú de navegación
    include_once 'Views/components/menus.php'; 
    ?>
    
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <div class="page-description d-flex align-items-center">
                        <div class="page-description-content flex-grow-1">
                            <h1>Mis Archivos Compartidos</h1>
                        </div>
                        <div class="page-description-actions d-flex gap-3">
                            <!-- Botón para volver a compartidos -->
                            <a href="<?php echo BASE_URL; ?>compartidos" class="btn btn-outline-secondary rounded-3 d-inline-flex align-items-center">
                                <i class="material-icons me-2">arrow_back</i>
                                <span>Volver a Compartidos</span>
                            </a>
                            <!-- Botón para actualizar -->
                            <a href="#" class="btn btn-primary rounded-3 d-inline-flex align-items-center" onclick="cargarCompartidosConmigo()">
                                <i class="material-icons me-2">refresh</i>
                                <span>Actualizar</span>
                            </a>
                            <!-- Botón para alternar vista (igual que en home.php) -->
                            <a href="#" class="toggle-view text-muted" data-view="grid" title="Cambiar vista">
                                <i class="material-icons">grid_view</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contenedor para los archivos con la misma estructura que home.php -->
            <div id="compartidos-conmigo-container">
                <?php if (!empty($data['archivos'])): ?>
                    <!-- Sección de archivos compartidos conmigo (similar a documentos recientes) -->
                    <div class="section-description">
                        <h1>
                            <i class="material-icons me-2" style="vertical-align: middle;">folder_shared</i>
                            Archivos que has agregado a tu espacio personal
                        </h1>
                    </div>
                    
                    <!-- Contenedor de archivos con clase dinámica igual que home.php -->
                    <div class="row files-container" id="files-container">
                        <?php foreach ($data['archivos'] as $archivo): ?>
                            <div class="col-md-6 col-12 file-item">
                                <div class="card file-manager-recent-item">
                                    <div class="card-body d-flex align-items-center">
                                        <!-- Icono de archivo (igual que home.php) -->
                                        <i class="material-icons-outlined text-primary align-middle m-r-sm file-icon">description</i>
                                        
                                        <!-- Información del archivo -->
                                        <div class="file-manager-recent-item-title flex-fill">
                                            <!-- Nombre del archivo como enlace -->
                                            <a href="#" class="ver-archivo-compartido" data-id="<?php echo $archivo['id']; ?>">
                                                <?php echo htmlspecialchars($archivo['nombre_personalizado'] ?: $archivo['nombre_archivo']); ?>
                                            </a>
                                            
                                            <!-- Información del propietario (en una línea separada pequeña) -->
                                            <div class="d-flex align-items-center mt-1">
                                                <img src="<?php echo !empty($archivo['avatar_propietario']) ? $archivo['avatar_propietario'] : BASE_URL .'Assets/images/avatar.jpg'; ?>" 
                                                     alt="Avatar" 
                                                     class="rounded-circle me-1" 
                                                     style="width: 16px; height: 16px;">
                                                <small class="text-muted">
                                                    Compartido por: <?php echo htmlspecialchars($archivo['propietario']); ?>
                                                </small>
                                            </div>
                                        </div>
                                        
                                        <!-- Tipo de archivo (similar al tamaño en home.php) -->
                                        <span class="p-h-sm text-muted">
                                            <?php echo $archivo['tipo']; ?>
                                        </span>
                                        
                                        <!-- Fecha de agregado (igual que home.php) -->
                                        <span class="p-h-sm text-muted">
                                            <?php echo date('d/m/Y', strtotime($archivo['fecha_aceptado'])); ?>
                                        </span>
                                        
                                        <!-- Menú de opciones (igual estructura que home.php) -->
                                        <a href="#" class="dropdown-toggle file-manager-recent-file-actions" 
                                           id="file-manager-recent-<?php echo $archivo['id']; ?>" 
                                           data-bs-toggle="dropdown" 
                                           aria-expanded="false">
                                            <i class="material-icons">more_vert</i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-end" 
                                            aria-labelledby="file-manager-recent-<?php echo $archivo['id']; ?>">
                                            <!-- Opción para descargar -->
                                            <li>
                                                <a class="dropdown-item" 
                                                   href="<?php echo BASE_URL; ?>archivos/descargar/<?php echo $archivo['id_archivo_original']; ?>" 
                                                   download="<?php echo $archivo['nombre_personalizado'] ?: $archivo['nombre_archivo']; ?>">
                                                    <i class="material-icons-outlined me-2">download</i>
                                                    Descargar
                                                </a>
                                            </li>
                                            <!-- Opción para compartir (nueva, similar a home.php) -->
                                            <li>
                                                <a class="dropdown-item compartir-archivo-compartido" 
                                                   href="#" 
                                                   data-id="<?php echo $archivo['id']; ?>">
                                                    <i class="material-icons-outlined me-2">share</i>
                                                    Compartir
                                                </a>
                                            </li>
                                            <!-- Opción para eliminar de mis archivos -->
                                            <li>
                                                <a class="dropdown-item text-danger eliminar-compartido-conmigo" 
                                                   href="#" 
                                                   data-id="<?php echo $archivo['id']; ?>">
                                                    <i class="material-icons-outlined me-2">delete</i>
                                                    Eliminar de mis archivos
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <!-- Estado vacío mejorado (manteniendo el diseño centrado pero más compacto) -->
                    <div class="section-description">
                        <h1>
                            <i class="material-icons me-2" style="vertical-align: middle;">folder_shared</i>
                            Mis Archivos Compartidos
                        </h1>
                    </div>
                    
                    <div class="row files-container">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body text-center py-5">
                                    <i class="material-icons-outlined text-muted mb-4" style="font-size: 4rem;">folder_shared</i>
                                    <h5 class="text-muted mb-3">No tienes archivos compartidos</h5>
                                    <p class="text-muted mb-4">
                                        Ve a la sección "Compartidos" y agrega archivos a tu espacio personal.
                                    </p>
                                    <a href="<?php echo BASE_URL; ?>compartidos" class="btn btn-primary rounded-3 d-inline-flex align-items-center">
                                        <i class="material-icons me-2">share</i>
                                        <span>Ver Archivos Compartidos</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal para visualizador de archivos (igual estructura que home.php) -->
<div class="modal fade" id="modalVisualizadorCompartidos" tabindex="-1" aria-labelledby="modalVisualizadorCompartidosLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalVisualizadorCompartidosLabel">Visualizar Archivo Compartido</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="contenidoVisualizadorCompartidos" class="text-center">
                    <!-- Aquí se cargará el contenido del archivo -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<?php 
// Incluye el modal
include_once 'Views/components/modal.php';
// Incluye el pie de página
include_once 'Views/template/footer.php'; 
?>